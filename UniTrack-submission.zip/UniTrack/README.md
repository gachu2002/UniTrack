# UniTrack

UniTrack is a web platform for university project supervision. Teachers manage projects, assign work, review student submissions, and track progress. Students view assigned work, submit progress, and attach evidence files.

## Main Features

- Cookie-based login/logout and current-session checks.
- Admin account management for admins, teachers, and students.
- Project workspace with lightweight class/folder grouping.
- Project creation, project detail pages, team members, and member roles.
- Milestones and official assignment creation/editing.
- Student assignment submissions with progress notes and evidence files.
- Teacher/admin review flow for submitted work.
- Resource links and uploaded evidence file download/delete support.
- Role-aware dashboard for admins, teachers, and students.

## Tech Stack

- Frontend: React, TypeScript, Vite, Tailwind CSS, React Router, TanStack Query, Zustand, Axios, React Hook Form, Zod.
- Backend: Go, chi, pgx, PostgreSQL, REST API, cookie-backed sessions.
- Database: PostgreSQL migrations managed with goose.
- Local services: Docker Compose for PostgreSQL.

## Requirements

- Node.js and pnpm.
- Go 1.25 or newer.
- Docker and Docker Compose.
- PostgreSQL, if not using Docker Compose.

## Project Structure

```text
apps/api/      Go REST API, database migrations, seed command
apps/web/      React/Vite frontend
compose.yaml   Local PostgreSQL service
Makefile       Common local development commands
```

## Environment Files

Example environment files are included:

```text
apps/api/.env.example
apps/web/.env.example
```

For local development, the Makefile already provides the common API environment values. The frontend API URL is:

```text
VITE_API_URL=http://localhost:8080/api/v1
```

## Setup And Run Locally

Install frontend dependencies:

```bash
pnpm install
```

Start PostgreSQL and run database migrations:

```bash
make db-up-local
```

Run the backend API:

```bash
make api-run-local
```

Run the frontend in another terminal:

```bash
pnpm --filter @unitrack/web dev
```

Open the frontend at:

```text
http://localhost:5173
```

Default local admin account:

```text
Email: admin@unitrack.local
Password: admin12345
```

## Optional Demo Data

After migrations are applied, seed demo data with:

```bash
cd apps/api
DATABASE_URL='postgres://postgres:postgres@localhost:55432/unitrack?sslmode=disable' go run ./cmd/seed
```

Demo users use password:

```text
DemoPass123!
```

Demo admin email:

```text
demo.admin@demo.unitrack.local
```

## Build And Test

Frontend build:

```bash
pnpm --filter @unitrack/web build
```

Frontend lint:

```bash
pnpm --filter @unitrack/web lint
```

Backend build:

```bash
make api-build
```

Backend tests:

```bash
make api-test
```

Validate database migrations:

```bash
make db-validate
```

## Notes

- The API listens on `http://localhost:8080` by default.
- The frontend calls the API at `http://localhost:8080/api/v1`.
- Local uploaded files are stored under `var/uploads` when using local file storage.
- The submission package intentionally excludes generated dependencies, build outputs, report files, and internal agent/documentation workflow files.
